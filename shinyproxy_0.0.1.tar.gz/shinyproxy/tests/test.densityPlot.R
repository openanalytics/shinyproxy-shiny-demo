
densityPlot()

densityPlot(nPoints = 5)

densityPlot(kernel = "triangular")

densityPlot(kernel = "epanechnikov")

